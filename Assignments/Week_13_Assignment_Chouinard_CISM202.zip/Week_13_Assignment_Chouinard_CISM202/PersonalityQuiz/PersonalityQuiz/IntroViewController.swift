//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Mark Chouinard on 11/27/21.
//

import UIKit

class IntroViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }

  @IBAction func unwindToQuizIntro(segue:UIStoryboardSegue) {

  }


}

